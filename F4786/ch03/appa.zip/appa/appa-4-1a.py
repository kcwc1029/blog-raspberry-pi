s = int(input("請輸入成績 => "))
if s >= 60:
    print("成績及格!")
else:
    print("成績不及格!")
