grade = 76
height = 175.5
weight = 75.5
print("成績 = " + str(grade))
print("身高 = " + str(height))
print("體重 = " + str(weight))
