print("第1個Python程式")
