import random

target = random.randint(1, 100)
print("1~100亂數值: " + str(target))
